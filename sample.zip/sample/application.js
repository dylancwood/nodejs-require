require('./ui/text_field.js');
require('./config.js');

var out = '@WalmartLabs';
console.log(out);

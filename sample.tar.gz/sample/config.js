require('ui/text_field.js');
require('ui/login_form.coffee');

var bar = 'foo';
console.log(bar);
